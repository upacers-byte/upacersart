import UpacersSite from "@/components/upacers/upacers-site"

export default function Page() {
  return <UpacersSite />
}
